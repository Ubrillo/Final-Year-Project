# turtlebot_cone > cone_dataset_v3
https://universe.roboflow.com/grandson/turtlebot_cone

Provided by a Roboflow user
License: CC BY 4.0

